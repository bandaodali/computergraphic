#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayScene.h"
#include "rayBox.h"

////////////////////////
//  Ray-tracing stuff //
////////////////////////
double RayBox::intersect(Ray3D ray,RayIntersectionInfo& iInfo,double mx){
	return -1;
}
BoundingBox3D RayBox::setBoundingBox(void){
	bBox = BoundingBox3D(center - (length / 2), center + (length / 2));
	return bBox;
}

//////////////////
// OpenGL stuff //
//////////////////
int RayBox::drawOpenGL(int materialIndex){
	material->drawOpenGL();

	Point3D v1 = (center - (length / 2));
	Point3D v2 = v1 + Point3D(0, 0, length.p[2]);
	Point3D v3 = v1 + Point3D(length.p[0], 0, length.p[2]);
	Point3D v4 = v1 + Point3D(length.p[0], 0, 0);	
	Point3D v5 = v1 + Point3D(0, length.p[1], 0);
	Point3D v6 = v5 + Point3D(0, 0, length.p[2]);
	Point3D v7 = v5 + Point3D(length.p[0], 0, length.p[2]);
	Point3D v8 = v5 + Point3D(length.p[0], 0, 0);

	Point3D n1 = Point3D(0, -length[1], 0);//bottom
	Point3D n2 = Point3D(0, length[1], 0); //top
	Point3D n3 = Point3D(-length[0], 0, 0);//left
	Point3D n4 = Point3D(length[0], 0, 0);//right
	Point3D n5 = Point3D(0, 0, length[2]);//front
	Point3D n6 = Point3D(0, 0, -length[2]);//back
	

	glVertex3f(center.p[0], center.p[1], center.p[2]);
	//bottom
	glBegin(GL_QUADS);
	glNormal3f(n1.p[0], n1.p[1], n1.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v1.p[0], v1.p[1], v1.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v2.p[0], v2.p[1], v2.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v3.p[0], v3.p[1], v3.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v4.p[0], v4.p[1], v4.p[2]);
	glEnd();
	//top
	glVertex3f(center.p[0], center.p[1], center.p[2]);
	glBegin(GL_QUADS);
	glNormal3f(n2.p[0], n2.p[1], n2.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v5.p[0], v5.p[1], v5.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v6.p[0], v6.p[1], v6.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v7.p[0], v7.p[1], v7.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v8.p[0], v8.p[1], v8.p[2]);
	glEnd();
	//left
	glVertex3f(center.p[0], center.p[1], center.p[2]);
	glBegin(GL_QUADS);
	glNormal3f(n3.p[0], n3.p[1], n3.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v1.p[0], v1.p[1], v1.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v2.p[0], v2.p[1], v2.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v6.p[0], v6.p[1], v6.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v5.p[0], v5.p[1], v5.p[2]);
	glEnd();
	//right 
	glVertex3f(center.p[0], center.p[1], center.p[2]);
	glBegin(GL_QUADS);
	glNormal3f(n4.p[0], n4.p[1], n4.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v4.p[0], v4.p[1], v4.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v3.p[0], v3.p[1], v3.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v7.p[0], v7.p[1], v7.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v8.p[0], v8.p[1], v8.p[2]);
	glEnd();
	//Front
	glVertex3f(center.p[0], center.p[1], center.p[2]);
	glBegin(GL_QUADS);
	glNormal3f(n5.p[0], n5.p[1], n5.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v2.p[0], v2.p[1], v2.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v3.p[0], v3.p[1], v3.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v7.p[0], v7.p[1], v7.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v6.p[0], v6.p[1], v6.p[2]);
	glEnd();
	//back 
	glVertex3f(center.p[0], center.p[1], center.p[2]);
	glBegin(GL_QUADS);
	glNormal3f(n6.p[0], n6.p[1], n6.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v1.p[0], v1.p[1], v1.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v4.p[0], v4.p[1], v4.p[2]);
	glTexCoord2d(1, 0);
	glVertex3f(v8.p[0], v8.p[1], v8.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v5.p[0], v5.p[1], v5.p[2]);
	glEnd();
	return material->index;
}
