#include <GL/glew.h>
#include <GL/glut.h>
#include <math.h>
#include "rayCamera.h"



//////////////////
// OpenGL stuff //
//////////////////
void RayCamera::drawOpenGL(void){
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	Point3D center = position + direction;
	gluLookAt(position.p[0], 
		position.p[1],
		position.p[2],
		center.p[0], center.p[1], center.p[2], 
		up.p[0], up.p[1], up.p[2]);
}
void RayCamera::rotateUp(Point3D center,float angle){
	Matrix3D translate3D;
	translate3D(0, 0) = 1;
	translate3D(1, 0) = 0;
	translate3D(2, 0) = 0;

	translate3D(0, 1) = 0;
	translate3D(1, 1) = 1;
	translate3D(2, 1) = 0;

	translate3D(0, 2) = 0;
	translate3D(1, 2) = 0;
	translate3D(2, 2) = 1;
	Matrix4D translate4D = Matrix4D(translate3D,-center);

	Point3D vx = Point3D(1, 0, 0);
	Point3D vy = Point3D(0, 1, 0);
	double cosx = up.dot(vx) / up.length();
	double sinx = up.crossProduct(vx).length() / up.length();
	
	double cosy = up.dot(vy) / up.length();
	double siny = up.crossProduct(vy).length() / up.length();

	Matrix3D rotatey3D;
	rotatey3D(0, 0) = cosy;
	rotatey3D(1, 0) = 0;
	rotatey3D(2, 0) = siny;

	rotatey3D(0, 1) = 0;
	rotatey3D(1, 1) = 1;
	rotatey3D(2, 1) = 0;

	rotatey3D(0, 2) = -siny;
	rotatey3D(1, 2) = 0;
	rotatey3D(2, 2) = cosy;
	Matrix4D rotatey4D = Matrix4D(rotatey3D, Point3D(0, 0, 0));

	Matrix3D rotatex3D;
	rotatex3D(0, 0) = 1;
	rotatex3D(1, 0) = 0;
	rotatex3D(2, 0) = 0;

	rotatex3D(0, 1) = 0;
	rotatex3D(1, 1) = cosx;
	rotatex3D(2, 1) = -sinx;

	rotatex3D(0, 2) = 0;
	rotatex3D(1, 2) = sinx;
	rotatex3D(2, 2) = cosx;

	Matrix4D rotatex4D = Matrix4D(rotatex3D, Point3D(0, 0, 0));
	Matrix4D first = rotatey4D*rotatex4D*translate4D;
	Matrix4D second = first.invert();

	Matrix3D rotatez3D;
	rotatez3D(0, 0) = cos(angle);
	rotatez3D(1, 0) = -sin(angle);
	rotatez3D(2, 0) = 0;

	rotatez3D(0, 1) = sin(angle);
	rotatez3D(1, 1) = cos(angle);
	rotatez3D(2, 1) = 0;

	rotatez3D(0, 2) = 0;
	rotatez3D(1, 2) = 0;
	rotatez3D(2, 2) = 1;
	Matrix4D rotatez4D = Matrix4D(rotatez3D, Point3D(0, 0, 0));

	Matrix4D total = second*rotatez4D*first;
	position = total*position;
	direction = total*direction;
}
void RayCamera::rotateRight(Point3D center,float angle){
	Matrix3D translate3D;
	translate3D(0, 0) = 1;
	translate3D(1, 0) = 0;
	translate3D(2, 0) = 0;

	translate3D(0, 1) = 0;
	translate3D(1, 1) = 1;
	translate3D(2, 1) = 0;

	translate3D(0, 2) = 0;
	translate3D(1, 2) = 0;
	translate3D(2, 2) = 1;
	Matrix4D translate4D = Matrix4D(translate3D, -center);

	Point3D vx = Point3D(1, 0, 0);
	Point3D vy = Point3D(0, 1, 0);
	double cosx = right.dot(vx) / right.length();
	double sinx = right.crossProduct(vx).length() / right.length();

	double cosy = right.dot(vy) / right.length();
	double siny = right.crossProduct(vy).length() / right.length();

	Matrix3D rotatey3D;
	rotatey3D(0, 0) = cosy;
	rotatey3D(1, 0) = 0;
	rotatey3D(2, 0) = siny;

	rotatey3D(0, 1) = 0;
	rotatey3D(1, 1) = 1;
	rotatey3D(2, 1) = 0;

	rotatey3D(0, 2) = -siny;
	rotatey3D(1, 2) = 0;
	rotatey3D(2, 2) = cosy;
	Matrix4D rotatey4D = Matrix4D(rotatey3D, Point3D(0, 0, 0));

	Matrix3D rotatex3D;
	rotatex3D(0, 0) = 1;
	rotatex3D(1, 0) = 0;
	rotatex3D(2, 0) = 0;

	rotatex3D(0, 1) = 0;
	rotatex3D(1, 1) = cosx;
	rotatex3D(2, 1) = -sinx;

	rotatex3D(0, 2) = 0;
	rotatex3D(1, 2) = sinx;
	rotatex3D(2, 2) = cosx;

	Matrix4D rotatex4D = Matrix4D(rotatex3D, Point3D(0, 0, 0));
	Matrix4D first = rotatey4D*rotatex4D*translate4D;
	Matrix4D second = first.invert();

	Matrix3D rotatez3D;
	rotatez3D(0, 0) = cos(angle);
	rotatez3D(1, 0) = -sin(angle);
	rotatez3D(2, 0) = 0;

	rotatez3D(0, 1) = sin(angle);
	rotatez3D(1, 1) = cos(angle);
	rotatez3D(2, 1) = 0;

	rotatez3D(0, 2) = 0;
	rotatez3D(1, 2) = 0;
	rotatez3D(2, 2) = 1;
	Matrix4D rotatez4D = Matrix4D(rotatez3D, Point3D(0, 0, 0));

	Matrix4D total = second*rotatez4D*first;
	position = total*position;
	direction = total*direction;
}
void RayCamera::moveForward(float dist){
	position += direction * dist;
}
void RayCamera::moveRight(float dist){
	position += right * dist;
}
void RayCamera::moveUp(float dist){
	position += up * dist;
}
