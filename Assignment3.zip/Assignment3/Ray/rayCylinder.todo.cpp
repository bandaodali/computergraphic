#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayScene.h"
#include "rayCylinder.h"


////////////////////////
//  Ray-tracing stuff //
////////////////////////
double RayCylinder::intersect(Ray3D ray,RayIntersectionInfo& iInfo,double mx){
	return -1;
}

BoundingBox3D RayCylinder::setBoundingBox(void){
	Point3D p;
	p = Point3D(radius, height / 2, radius);
	bBox = BoundingBox3D(center + p, center - p);
	return bBox;
}

//////////////////
// OpenGL stuff //
//////////////////
int RayCylinder::drawOpenGL(int materialIndex){
	
	/*material->drawOpenGL();
	GLUquadricObj* gq = gluNewQuadric();
	glVertex3f(center.p[0], center.p[1], center.p[2] - height / 2);
	glRotated(90, 1, 0, 0);	
	gluDisk(gq, 0, radius, openGLComplexity*2, openGLComplexity);
	gluCylinder(gq, radius, radius, height, openGLComplexity*2, openGLComplexity);
	glTranslatef(0, 0, height);
	glVertex3f(center.p[0], center.p[1], center.p[2] + height / 2);
	gluDisk(gq, 0, radius, openGLComplexity*2, openGLComplexity);*/
	material->drawOpenGL();
	glBegin(GL_POLYGON);
	for (int i = 0; i<50; i++) {
		glNormal3f(0, height, 0);
		glVertex3f(radius*cos(2 * PI / 50 * i), center.p[1]-height / 2, radius*sin(2 * PI / 50 * i));
	}
	glEnd();

	glPushMatrix();	
	glTranslatef(center.p[0], center.p[1] - height / 2, center.p[2]);
	glRotatef(-90, 1.f, 0.f, 0.f);
	GLUquadricObj* gq = gluNewQuadric();
	glDisable(GL_CULL_FACE);
	gluCylinder(gq, radius,radius, height, 2*openGLComplexity , openGLComplexity);
	glPopMatrix();

	glBegin(GL_POLYGON);
	for (int i = 0; i<50; i++) {
		glNormal3f(0, height, 0);
		glVertex3f(radius*cos(2 * PI / 50 * i), center.p[1]+height/2, radius*sin(2 * PI / 50 * i));
	}
	glEnd();
	glPopMatrix();
	return material->index;
}
