#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayDirectionalLight.h"
#include "rayScene.h"

////////////////////////
//  Ray-tracing stuff //
////////////////////////
Point3D RayDirectionalLight::getDiffuse(Point3D cameraPosition,RayIntersectionInfo& iInfo){
	double judge = iInfo.normal.dot(this[0].direction.negate());
	if (judge < 0) {
		return Point3D(0, 0, 0);
	}
	Point3D id = iInfo.material->diffuse * this[0].color *(judge);
	/*if (iInfo.material->ambient[0] == 0) {
		printf("DirectionalLight Material A is (%f,%f,%f)\t\t", iInfo.material->ambient[0], iInfo.material->ambient[0], iInfo.material->ambient[0]);
		printf("DirectionalLight Normal is (%f,%f,%f)\n", id[0], id[1], id[2]);
	}*/	
	return id;
}
Point3D RayDirectionalLight::getSpecular(Point3D cameraPosition, RayIntersectionInfo& iInfo) {
	Point3D input = this[0].direction;
	Point3D norm = iInfo.normal;
	Point3D reflect = input + norm + norm;
	Point3D r = reflect.unit();
	Point3D viewer = cameraPosition - iInfo.iCoordinate;
	Point3D v = viewer / viewer.length();
	double vr = fmax(0, r.dot(v)); 
	return iInfo.material->specular*pow(vr, iInfo.material->specularFallOff)*this[0].color;
}
int RayDirectionalLight::isInShadow(RayIntersectionInfo& iInfo,RayShape* shape){
	Ray3D ray = Ray3D(iInfo.iCoordinate, this[0].direction.negate());
	RayIntersectionInfo info = RayIntersectionInfo(); 
	if (shape->intersect(ray, info, -1.0) < 0 ){
		return 0;
	}
	if (info.material->specularFallOff == iInfo.material->specularFallOff) {
		return 0;
	}
	return 1;
}
Point3D RayDirectionalLight::transparency(RayIntersectionInfo& iInfo,RayShape* shape,Point3D cLimit){
	Point3D position = iInfo.iCoordinate;
	double t = 0.001;
	Ray3D ray = Ray3D(position + this[0].direction.negate()*t, this[0].direction.negate());
	RayIntersectionInfo rinfo;
	double hit = shape->intersect(ray, rinfo, -1.0);
	if (hit < 0) {
		return Point3D(1, 1, 1);
	}
	else {
		Point3D factor = rinfo.material->transparent;
		return factor;
	}	
}

//////////////////
// OpenGL stuff //
//////////////////
void RayDirectionalLight::drawOpenGL(int index){
	//GL_AMBIENT, GL_DIFFUSE, GL_SPECULAR, GL_POSITION(0,0,1,0),
	//GL_SPOT_CUTOFF, GL_SPOT_DIRECTION(0,0,-1), GL_SPOT_EXPONENT, 
	//GL_CONSTANT_ATTENUATION, GL_LINEAR_ATTENUATION, and GL_QUADRATIC_ATTENUATION

	/*GLfloat ambient(LIGHT_PROPS);*/
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0 + index);

	GLfloat light_color[4] = { color.p[0] , color.p[1], color.p[2], 1.f };

	/*glLightfv(GL_LIGHT0 + index, GL_AMBIENT, light_color);*/
	/*glLightfv(GL_LIGHT0 + index, GL_SPECULAR, light_color);*/

	glLightfv(GL_LIGHT0 + index, GL_DIFFUSE, light_color);

	GLfloat light_position[4] = { -direction.p[0],-direction.p[1],-direction.p[2], 0.f };
	GLfloat light_direction[3] = { direction.p[0],direction.p[1],direction.p[2] };
	glLightfv(GL_LIGHT0 + index, GL_POSITION, light_position);

}