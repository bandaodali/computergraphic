#include <stdlib.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayGroup.h"
#include<map>
using namespace std;

////////////////////////
//  Ray-tracing stuff //
////////////////////////

//if (sNum > 0)
//{
//	if (bBox.intersect(newray) > 0) {
//		RayIntersectionInfo info;
//		map<double, int> temp;
//		int hitnums = 0;
//		for (int i = 0; i < 64; i++) {
//			if (hits[i].shape[0].bBox.intersect(newray) > 0) {
//				double distance = hits[i].shape[0].bBox.intersect(newray);
//				hits[i].t = distance;
//				temp[distance] = i;
//				hitnums++;
//			}
//			qsort(hits, hitnums, sizeof(hits), RayShapeHit::Compare);
//		}
//		for (int i = 0; i < hitnums; i++) {
//			for (int j = 0; j < hits[i].shape[0].openGLComplexity; j++) {
//				double t = hits[i].shape[j].intersect(ray, info, -1);
//				if (t > 0 && (t < mx || mx < 0)) {
//					iInfo = info;
//					mx = t;
//				}
//			}
//			if (mx > 0) {
//				iInfo.iCoordinate = this[0].getMatrix()*iInfo.iCoordinate;
//				iInfo.normal = this[0].getNormalMatrix().multDirection(iInfo.normal).unit();
//				mx = (p0 - iInfo.iCoordinate).length();
//				break;
//			}
//		}
//	}
//	/*map<double, int>::iterator iter;
//	iter = temp.begin();
//	int i = 1;
//	while (iter != temp.end()) {
//	shapes[i] = hits[iter->second].shape;
//	}
//	for (int i = 1; i < temp.size(); i++) {
//	for (int j = 0; j < shapes[i]->openGLComplexity; j++) {
//	double t = shapes[i][j].intersect(ray, info, -1);
//	if (t > 0 && (t < mx) || mx < 0) {
//	iInfo = info;
//	mx = t;
//	}
//	}
//	}*/		
//}
//else {
//	for (int i = 0; i < this[0].sNum; i++) {
//		RayIntersectionInfo info;
//		/*printf("%f, %f\n",this[0].shapes[i]->bBox.p[0].p[0],this[1].shapes[i]->bBox.p[1].p[0]);*/
//		double t = this[0].shapes[i]->intersect(newray, info, -1);
//		/*printf("RayGroup: distance is %f\n", this[0].hits[i].t,this[0].shapes);*/

//		if (t > 0 && (t < mx || mx < 0)) {
//			iInfo = info;
//			mx = t;
//		}
//		//qsort(hits, sNum, sizeof(hits), RayShapeHit::Compare);
//	}
//	if (mx > 0) {
//		iInfo.iCoordinate = this[0].getMatrix()*iInfo.iCoordinate;
//		iInfo.normal = this[0].getNormalMatrix().multDirection(iInfo.normal).unit();
//		mx = (p0 - iInfo.iCoordinate).length();
//	}
//}
double RayGroup::intersect(Ray3D ray, RayIntersectionInfo& iInfo, double mx) {
	/*printf("rayscene : direction is %f,%f,%f\n", ray.direction.p[0], ray.direction.p[1], ray.direction.p[2]);*/
	Matrix4D transformation = this[0].getMatrix();
	Point3D p0 = ray.position;
	Point3D d0 = ray.direction;
	Point3D p = getInverseMatrix().multPosition(p0);
	Point3D d = getInverseMatrix().multDirection(d0).unit();
	Ray3D newray = Ray3D(p, d);
	mx = -1;
	if (bBox.intersect(newray) >= 0) {
			/*int hitnum = 0;
			for (int i = 0; i < sNum; i++) {
			double distance = shapes[i][0].bBox.intersect(newray);
			if (distance > 0) {
				hits[hitnum].shape[0] = shapes[i][0];
				hits[hitnum].t = distance;
				hitnum++;
			}
			}
			printf("qsort be used\n");
			qsort(hits, hitnum, sizeof(hits), RayShapeHit::Compare);*/
			RayIntersectionInfo info;
			for (int i = 0; i < sNum; i++) {
				double t = shapes[i][0].intersect(newray, info, -1);
				if (t > 0 && (t < mx) || mx < 0) {
					iInfo = info;
					mx = t;
				}
			}
			if (mx > 0) {
				iInfo.iCoordinate = this[0].getMatrix()*iInfo.iCoordinate;
				iInfo.normal = this[0].getNormalMatrix().multDirection(iInfo.normal).unit();
				mx = (p0 - iInfo.iCoordinate).length();
			}
	}
	return mx;
	//mx = -1;
	//for (int i = 0; i < sNum; i++) {
	//	RayIntersectionInfo info;	//
	//	double t = this[0].shapes[i]->intersect(newray, info, -1);
	//	
	//	if (t > 0 && (t < mx || mx < 0)) {
	//		iInfo = info;
	//		mx = t;
	//	}
	//	//qsort(hits, snum, sizeof(hits), rayshapehit::compare);
	//}
	//if (mx > 0) {
	//	iInfo.iCoordinate = this[0].getMatrix()*iInfo.iCoordinate;
	//	iInfo.normal = this[0].getNormalMatrix().multDirection(iInfo.normal).unit();
	//	mx = (p0 - iInfo.iCoordinate).length();
	//}
	//return mx;	
}

BoundingBox3D RayGroup::setBoundingBox(void){
	Point3D* pList;
	BoundingBox3D tBBox;
	pList = new Point3D[sNum * 2];
	for (int i = 0; i<sNum; i++) {
		tBBox = shapes[i]->setBoundingBox();
		pList[2 * i] = tBBox.p[0];
		pList[2 * i + 1] = tBBox.p[1];
	}
	tBBox = BoundingBox3D(pList, sNum * 2);

	delete[] pList;
	bBox = tBBox.transform(getMatrix());
	return bBox;
}

//uniform grids
//int divide = 4;
//double dx = (b.p[1].p[0] - b.p[0].p[0])/4;
//double dy = (b.p[1].p[1] - b.p[0].p[1])/4;
//double dz = (b.p[1].p[2] - b.p[0].p[2])/4;
//for (int z = 0; z < divide; z++) {
//	for (int y = 0; y < divide; y++) {
//		for (int x = 0; x < divide; x++) {
//			Point3D p1 = Point3D(b.p[1].p[0] + (x + 1)*dx, b.p[1].p[1] + (y + 1)*dy, b.p[1].p[2] + (z + 1)*dz);
//			Point3D p0 = Point3D(b.p[0].p[0] + x*dx, b.p[0].p[1] + y*dy, b.p[0].p[2] + z*dz);
//			BoundingBox3D gridbox = BoundingBox3D(p0, p1);
//			int index = 0;
//			for (int i = 0; i < sNum; i++) {					
//				/*if ((shapes[i][0].bBox.p[0].p[0] > p0.p[0] && shapes[i][0].bBox.p[0].p[0] < p1.p[0]) ||
//					(shapes[i][0].bBox.p[1].p[0] > p0.p[0] && shapes[i][0].bBox.p[1].p[0] < p1.p[0]) ||
//					(shapes[i][0].bBox.p[0].p[1] > p0.p[1] && shapes[i][0].bBox.p[0].p[1] < p1.p[1]) ||
//					(shapes[i][0].bBox.p[1].p[1] > p0.p[1] && shapes[i][0].bBox.p[1].p[1] < p1.p[1]) ||
//					(shapes[i][0].bBox.p[0].p[2] > p0.p[2] && shapes[i][0].bBox.p[0].p[2] < p1.p[2]) ||
//					(shapes[i][0].bBox.p[1].p[2] > p0.p[2] && shapes[i][0].bBox.p[1].p[2] < p1.p[2])) {
//					hits[16 * z + 4 * y + x].shape[openGLComplexity] = shapes[i][0];
//					hits[16 * z + 4 * y + x].shape[openGLComplexity++].bBox = gridbox;
//				}*/
//				//intercet shapes(in box) with certain grid(x,y,z)
//				//s0,p0,s1,p1; p0,s0,s1,p1 ;p0,s0,p1,s1; 
//				if (((shapes[i][0].bBox.p[0].p[0] > p0.p[0] && shapes[i][0].bBox.p[0].p[0] < p1.p[0]) &&
//					(shapes[i][0].bBox.p[0].p[1] > p0.p[1] && shapes[i][0].bBox.p[0].p[1] < p1.p[1]) &&
//					(shapes[i][0].bBox.p[0].p[2] > p0.p[2] && shapes[i][0].bBox.p[0].p[2] < p1.p[2])) ||
//					((shapes[i][0].bBox.p[1].p[0] > p0.p[0] && shapes[i][0].bBox.p[1].p[0] < p1.p[0]) &&
//					(shapes[i][0].bBox.p[1].p[1] > p0.p[1] && shapes[i][0].bBox.p[1].p[1] < p1.p[1]) &&
//					(shapes[i][0].bBox.p[1].p[2] > p0.p[2] && shapes[i][0].bBox.p[1].p[2] < p1.p[2]))) {
//					hits[16 * z + 4 * y + x].shape[index] = shapes[i][0];
//					hits[16 * z + 4 * y + x].shape[index++].bBox = gridbox;
//					printf("d%\n", hits[16 * z + 4 * y + x].shape[index]);
//				}
//			}
//		}
//	}
//}

int StaticRayGroup::set(void){
	inverseTransform = localTransform.invert();
	normalTransform = localTransform.transpose().invert();
	return 1;
}
//////////////////
// OpenGL stuff //
//////////////////

int RayGroup::drawOpenGL(int materialIndex){
	Matrix4D newMatrix = getMatrix();
	double transforms[16];
	int i, j;
	for (i = 0;  i < 4; i++) {
		for (j = 0;  j < 4; j++) {
			transforms[(i * 4) + j] = newMatrix.m[i][j];
		}
	}
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
	for (int i = 0; i < sNum; i++) {
		glPushMatrix();
		glMultMatrixd(transforms);
		shapes[i]->drawOpenGL(materialIndex);
		glPopMatrix();
	}
	return 0;
}

/////////////////////
// Animation Stuff //
/////////////////////
Matrix4D ParametrizedEulerAnglesAndTranslation::getMatrix(void){
	return Matrix4D::IdentityMatrix();
}
Matrix4D ParametrizedClosestRotationAndTranslation::getMatrix(void){
	return Matrix4D::IdentityMatrix();
}
Matrix4D ParametrizedRotationLogarithmAndTranslation::getMatrix(void){
	return Matrix4D::IdentityMatrix();
}
Matrix4D ParametrizedQuaternionAndTranslation::getMatrix(void){
	return Matrix4D::IdentityMatrix();
}
