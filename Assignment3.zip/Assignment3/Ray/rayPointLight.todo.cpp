#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayPointLight.h"
#include "rayScene.h"

////////////////////////
//  Ray-tracing stuff //
////////////////////////
Point3D RayPointLight::getDiffuse(Point3D cameraPosition,RayIntersectionInfo& iInfo){
	Point3D l = iInfo.iCoordinate - this[0].location;;
	double distance = l.length();
	double judge = iInfo.normal.dot(l.negate());
	if (judge < 0) {
		return Point3D(0, 0, 0);
	}
	Point3D il = this[0].color / (this[0].constAtten + this[0].linearAtten * distance + this[0].quadAtten * distance * distance);
	Point3D id = iInfo.material->diffuse * (judge) * il;
	return id;
}
Point3D RayPointLight::getSpecular(Point3D cameraPosition,RayIntersectionInfo& iInfo){
	Point3D l = iInfo.iCoordinate - this[0].location;;
	double distance = l.length();
	Point3D v = cameraPosition - iInfo.iCoordinate;
	v = v / v.length();
	double cosc = iInfo.normal.dot(l.negate());
	double cosac = v.dot(iInfo.normal);
	double cosvl = v.dot(l.negate());
	if (cosc < 0 || cosac < 0 || cosvl > cosac || cosvl > cosc) {
		return Point3D(0, 0, 0);
	}
	double cosa = cos(acos(cosac) - acos(cosc));
	Point3D il = this[0].color / (this[0].constAtten + this[0].linearAtten * distance + this[0].quadAtten * distance * distance);
	Point3D result = iInfo.material->specular*pow(cosa, iInfo.material->specularFallOff)*il;
	return result;
}
int RayPointLight::isInShadow(RayIntersectionInfo& iInfo,RayShape* shape){
	Point3D l = iInfo.iCoordinate - this[0].location;;
	double distance = l.length();
	Ray3D ray = Ray3D(iInfo.iCoordinate, l.negate());
	RayIntersectionInfo info = RayIntersectionInfo();
	if (shape->intersect(ray, info, -1.0) < 0) {
		return 0;
	}
	if (info.material->specularFallOff == iInfo.material->specularFallOff) {
		return 0;
	}
	return 1;
}
Point3D RayPointLight::transparency(RayIntersectionInfo& iInfo,RayShape* shape,Point3D cLimit){
	Point3D l = iInfo.iCoordinate - this[0].location;;
	double distance = l.length();
	Point3D position = iInfo.iCoordinate;
	double t = 0.001;
	Ray3D ray = Ray3D(position + l.negate()*t, l.negate());
	RayIntersectionInfo rinfo;
	double hit = shape->intersect(ray, rinfo, -1.0);
	if (hit < 0) {
		return Point3D(1, 1, 1);
	}
	else {
		Point3D factor = rinfo.material->transparent;
		return factor;
	};
}


//////////////////
// OpenGL stuff //
//////////////////
void RayPointLight::drawOpenGL(int index){
	//GL_AMBIENT, GL_DIFFUSE, GL_SPECULAR, GL_POSITION(0,0,1,0),
	//GL_SPOT_CUTOFF, GL_SPOT_DIRECTION(0,0,-1), GL_SPOT_EXPONENT, 
	//GL_CONSTANT_ATTENUATION, GL_LINEAR_ATTENUATION, and GL_QUADRATIC_ATTENUATION
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0 + index);

	GLfloat light_color[4] = { color.p[0] , color.p[1], color.p[2], 1.f };
 	GLfloat light_position[4] = { location.p[0],location.p[1],location.p[2],1.f};
	//GLfloat constAttenuation[1] = { constAtten };
	//GLfloat linearAttenuation[1] = { linearAtten };
	//GLfloat quadAttenuation[1] = { quadAtten };

	glLightfv(GL_LIGHT0 + index, GL_AMBIENT, light_color);

	glLightfv(GL_LIGHT0 + index, GL_DIFFUSE, light_color);

	glLightfv(GL_LIGHT0 + index, GL_SPECULAR, light_color);

	glLightfv(GL_LIGHT0 + index, GL_POSITION, light_position);

	glLightf(GL_LIGHT0 + index, GL_CONSTANT_ATTENUATION, constAtten);

	glLightf(GL_LIGHT0 + index, GL_LINEAR_ATTENUATION, linearAtten);

	glLightf(GL_LIGHT0 + index, GL_QUADRATIC_ATTENUATION, quadAtten);
}