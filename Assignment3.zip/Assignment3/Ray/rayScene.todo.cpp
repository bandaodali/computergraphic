#include "rayScene.h"
#include <GL/glew.h>
#include <GL/glut.h>
#include <math.h>


///////////////////////
// Ray-tracing stuff //
///////////////////////

Point3D RayScene::Reflect(Point3D v,Point3D n){
	/*return (v.negate() + n + n).unit();*/
	Point3D a = v + n*n.dot(v.negate());
	return (v.negate() + a + a).unit();	
}

int RayScene::Refract(Point3D v,Point3D n,double ir,Point3D& refract){
	/*refract = v;*/
	Point3D v0 = v.negate();
	Point3D vn = v.crossProduct(n);
	double sini = vn.length() / (v0.length()*n.length());
	double sinr; double nr; double ni;
	double cosi = v0.dot(n);
	double cosr = cos(asin(sini));
	if (v0.dot(n) < 0) {
		 nr = ir;
		 ni = 1;
	}
	if (v0.dot(n) == 0) {
		return 0;
	}
	if (v0.dot(n) > 0) {
		nr = 1;
	 	ni = ir;
	}
	sinr = sini * ni / nr;
	if (sinr > 1) {
		return 0;
	}
	refract = n*(ni*cosi / nr - cosr) - v0;
	return 1;
}

Ray3D RayScene::GetRay(RayCamera* camera,int i,int j,int width,int height){
	double high = camera->heightAngle;
	double ratio = camera->aspectRatio;
	Point3D p0 = camera->position;
	Point3D towards = camera->direction;
	Point3D up = camera->up;
	Point3D right = camera->right;
	double d = 200;
	Point3D p1i = p0 + towards*d - right*d*tan(high);
	Point3D p2i = p0 + towards*d + right*d*tan(high);
	Point3D pi = p1i + (p2i - p1i)*((i + 0.5) / height);
	Point3D p1j = p0 + towards*d - up*d*tan(high);
	Point3D p2j = p0 + towards*d + up*d*tan(high);
	Point3D pj = p1j + (p2j - p1j)*((j + 0.5) / width);
	Point3D pij = pi + pj;
	Point3D v = (pij - p0)/(pij - p0).length();
	/*printf("RayScene : source is %f,%f,%f, direction is %f,%f,%f\n", p0.p[0], p0.p[1], p0.p[2], v.p[0], v.p[1], v.p[2]);*/
	Ray3D res = Ray3D(p0, v);
	return res;
}

Point3D RayScene::GetColor(Ray3D ray,int rDepth,Point3D cLimit){
	RayIntersectionInfo info = RayIntersectionInfo();
	RayIntersectionInfo reflectinfo;
	Ray3D reflectray; Ray3D refractray; double refract;
	double hit = this[0].group->intersect(ray, info, -1.0);	
	rDepth--;
	Point3D result = background;
	Point3D result2 = Point3D(0, 0, 0);
	if (hit > 0) {
		/*printf("Ambient is %f, Emissive is %f", info.material->ambient, info.material->emissive);*/ 
		//GetSurfaceColor
		result = info.material->emissive;
		for (int i = 0; i < this[0].lightNum; i++) {
			result = info.material->ambient * this[0].ambient;
			result2 = this[0].lights[i]->getDiffuse(ray.position, info);
			result2 = result2 + this[0].lights[i]->getSpecular(ray.position, info);
			//shadow & transparence 
			int judge = 0;
			Point3D transparence = Point3D(1,1,1);
			for (int j = 0; j < this[0].group->sNum; j++) {
				judge += this[0].lights[i]->isInShadow(info, this[0].group->shapes[j]);	
				transparence = transparence*lights[i]->transparency(info, this[0].group->shapes[j], cLimit);
			}
			if (judge >= 1) {
				result2 = result2*transparence;
			}			
			result = result + result2;
		}
		//reflect
		reflectray.direction = Reflect(ray.direction, info.normal);
		reflectray.position = info.iCoordinate + reflectray.direction * 0.0001;
		if (rDepth > 0 && info.material->specular.p[0] > cLimit.p[0] && info.material->specular.p[1] > cLimit.p[1] && info.material->specular.p[2] > cLimit.p[2]) {
			if (ray.direction.negate().dot(info.normal) >= 0) {
				Point3D result3 = GetColor(reflectray, rDepth, cLimit) * info.material->specular; 
				if (result3.p[0] != background.p[0] && result3.p[1] != background.p[1] && result3.p[2] != background.p[2])
					result += result3;
			}			
		}
		//refract
		/*if (Refract(ray.direction, info.normal, info.material->refind, refractray.direction)) {
			refractray.position = info.iCoordinate + ray.direction * 0.0001;
			if (rDepth > 0 && info.material->transparent.p[0] > cLimit.p[0] && info.material->transparent.p[1] > cLimit.p[1] && info.material->transparent.p[2] > cLimit.p[2]) {
				Point3D result3 = GetColor(refractray, rDepth, cLimit) * info.material->transparent;
				if (result3.p[0] != background.p[0] && result3.p[1] != background.p[1] && result3.p[2] != background.p[2])
					result += result3;
			}
		}*/		
		if (result.p[0] > 1) {
			result.p[0] = 1;
		}
		if (result.p[1] > 1) {
			result.p[1] = 1;
		}
		if (result.p[2] > 1) {
			result.p[2] = 1;
		}
	}
	return result;
}

//////////////////
// OpenGL stuff //
//////////////////
void RayMaterial::drawOpenGL(void){

	GLfloat material_emissive_color[4] = { emissive[0],emissive[1],emissive[2],1.f };
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, material_emissive_color);

	GLfloat material_ambient_color[4] = { ambient.p[0], ambient.p[1], ambient.p[2], 1.f };
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, material_ambient_color);

	GLfloat material_diffuse_color[4] = {diffuse.p[0], diffuse.p[1], diffuse.p[2], 1.f };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, material_diffuse_color);

	GLfloat material_specular_color[4] = { specular.p[0], specular.p[1], specular.p[2], 1.f };
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, material_specular_color);

	GLfloat material_shininess_color[1] = { specularFallOff };
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, material_shininess_color);
	
	if (tex) {
		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, tex->openGLHandle);
	}
	else {
		glDisable(GL_TEXTURE_2D);
	}

	/*GLuint checkeboardTextureHandle;
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, checkeboardTextureHandle);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);*/
}
void RayTexture::setUpOpenGL(void) {
	if (img == NULL) {
		return;
	}
	glGenTextures(1, &openGLHandle);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, openGLHandle);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, img->width(), img->height(), 0, GL_RGBA, GL_UNSIGNED_BYTE, (void *)&img->pixel(0, 0));
	glBindTexture(GL_TEXTURE_2D, -1);
		/*int width = img->width();
		int height = img->height();
		float *data = new float[width*height * 4];
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				data[i*width * 4 + j * 4 + 0] = img->pixel(j, i).r * 255;
				printf("R is %f\n", img->pixel(j, i).a);
				data[i*width * 4 + j * 4 + 1] = img->pixel(j, i).g * 255;
				data[i*width * 4 + j * 4 + 2] = img->pixel(j, i).b * 255;
				data[i*width * 4 + j * 4 + 3] = img->pixel(j, i).a * 255;
			}
		}*/
}
