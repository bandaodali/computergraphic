#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayScene.h"
#include "raySphere.h"
#define MIN(a,b) (a<b)?a:b
////////////////////////
//  Ray-tracing stuff //
////////////////////////
double RaySphere::intersect(Ray3D ray, RayIntersectionInfo& iInfo, double mx) {
	/*printf("rayscene : direction is %f,%f,%f\n", ray.direction.p[0], ray.direction.p[1], ray.direction.p[2]);*/
	Point3D temp = ray.position - this[0].center;
	double b = ray.direction.dot(temp) * 2;
	double c = temp.squareNorm() - this[0].radius*this[0].radius;
	if (b*b - 4 * c < 0) {
		return -1.0;
	}
	double d = sqrt(b * b - 4 * c);
	double t1 = (-b + d) / 2;
	double t2 = (-b - d) / 2;
	double t;
	if (t1 <= 0) {
		if (t2 <= 0) {
			return -1.0;
		}
		else t = t2;		
	}
	else {
		if (t2 <= 0) {
			t = t1;
		}
		else t = MIN(t1, t2);
	}
	/*printf("RaySphere : intersect is %f,%f,%f\n", t1, t2, t);*/
	double distance = (ray.direction*t).length();
	iInfo.iCoordinate = ray.position + ray.direction*t;
	temp = iInfo.iCoordinate - this[0].center;
	iInfo.normal = temp / temp.length();
	iInfo.material = this[0].material;
	/*printf("Ambient(r,g,b) is %f, %f, %f\n", this[0].material->emissive.p[0], this[0].material->emissive.p[1], this[0].material->emissive.p[2]);
	printf("RaySphere : intersect is %f,%f,%f\n", iInfo.iCoordinate.p[0], iInfo.iCoordinate.p[1], iInfo.iCoordinate.p[2]);*/
	/*printf("Ambient(r,g,b) is %f, %f, %f\n", iInfo.material->ambient.p[0], iInfo.material->ambient.p[1], iInfo.material->ambient.p[2]);*/
	return distance;
}
BoundingBox3D RaySphere::setBoundingBox(void){
	Point3D p = Point3D(radius, radius, radius);
	bBox = BoundingBox3D(center + p, center - p);
	return bBox;;
}

//////////////////
// OpenGL stuff //
//////////////////
int RaySphere::drawOpenGL(int materialIndex){
	material->drawOpenGL();
	GLUquadricObj* gq = gluNewQuadric(); 
	gluSphere(gq, radius, openGLComplexity* 2, openGLComplexity);	
	return material->index;
}
