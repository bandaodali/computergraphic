#include <math.h>
#include <GL/glew.h>
#include <GL/glut.h>
#include "rayScene.h"
#include "raySpotLight.h"


////////////////////////
//  Ray-tracing stuff //
////////////////////////
Point3D RaySpotLight::getDiffuse(Point3D cameraPosition,RayIntersectionInfo& iInfo){
	Point3D v = iInfo.iCoordinate - this[0].location;
	double distance = v.length();
	double judge = this[0].direction.dot(v);
	if (judge > cos(this[0].cutOffAngle)) {
		Point3D il = this[0].color * pow(judge,this[0].dropOffRate) / (this[0].constAtten + this[0].linearAtten * distance + this[0].quadAtten * distance);
		double judge2 = iInfo.normal.dot(v.negate());
		if (judge2 < 0) {
			return Point3D(0, 0, 0);
		}
		Point3D id = iInfo.material->diffuse * (iInfo.normal.dot(v.negate())) * il;
		return id;
	}
	return Point3D(0,0,0);
}
Point3D RaySpotLight::getSpecular(Point3D cameraPosition,RayIntersectionInfo& iInfo){
	Point3D v1 = iInfo.iCoordinate - this[0].location;
	double distance = v1.length();
	double judge = this[0].direction.dot(v1);
	if (judge > cos(this[0].cutOffAngle)) {
		Point3D il = this[0].color * pow(judge,this[0].dropOffRate) / (this[0].constAtten + this[0].linearAtten * distance + this[0].quadAtten * distance);
		double judge2 = iInfo.normal.dot(v1.negate());
		if (judge2 < 0) {
			return Point3D(0, 0, 0);
		}
		Point3D v = cameraPosition - iInfo.iCoordinate;
		v = v / v.length();
		double cosc = iInfo.normal.dot(this[0].direction.negate());
		double cosac = v.dot(iInfo.normal);
		double cosvl = v.dot(this[0].direction.negate());
		if (cosc < 0 || cosac < 0 || cosvl > cosac || cosvl > cosc) {
			return Point3D(0, 0, 0);
		}
		double cosa = cos(acos(cosac) - acos(cosc));
		Point3D result = iInfo.material->specular*pow(cosa, iInfo.material->specularFallOff)*il;
		return result;
	} 
	return Point3D(0,0,0);
}
int RaySpotLight::isInShadow(RayIntersectionInfo& iInfo,RayShape* shape){
	Ray3D ray = Ray3D(iInfo.iCoordinate, this[0].direction.negate());
	RayIntersectionInfo info = RayIntersectionInfo();
	if (shape->intersect(ray, info, -1.0) < 0) {
		return 0;
	}
	if (info.material->specularFallOff == iInfo.material->specularFallOff) {
		return 0;
	}
	return 1;
}
Point3D RaySpotLight::transparency(RayIntersectionInfo& iInfo,RayShape* shape,Point3D cLimit){
	Point3D position = iInfo.iCoordinate;
	double t = 0.001;
	Ray3D ray = Ray3D(position + this[0].direction.negate()*t, this[0].direction.negate());
	RayIntersectionInfo rinfo;
	double hit = shape->intersect(ray, rinfo, -1.0);
	if (hit < 0) {
		return Point3D(1, 1, 1);
	}
	else {
		Point3D factor = rinfo.material->transparent;
		return factor;
	}
}

//////////////////
// OpenGL stuff //
//////////////////
void RaySpotLight::drawOpenGL(int index){
	//GL_AMBIENT, GL_DIFFUSE, GL_SPECULAR, GL_POSITION(0,0,1,0),
	//GL_SPOT_CUTOFF, GL_SPOT_DIRECTION(0,0,-1), GL_SPOT_EXPONENT, 
	//GL_CONSTANT_ATTENUATION, GL_LINEAR_ATTENUATION, and GL_QUADRATIC_ATTENUATION
	
	//GLfloat constAttenuation[1] = { constAtten };
	//GLfloat linearAttenuation[1] = { linearAtten };
	//GLfloat quadAttenuation[1] = { quadAtten };
	//GLfloat cutOff[1] = { cutOffAngle }; 
	//GLfloat dropOff[1] = { dropOffRate };
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0 + index);

	GLfloat light_color[4] = { color.p[0] , color.p[1], color.p[2], 1.f };
	GLfloat light_position[4] = { location.p[0],location.p[1],location.p[2],1.f };
	GLfloat light_direction[3] = { direction.p[0],direction.p[1],direction.p[2] };

	glLightfv(GL_LIGHT0 + index, GL_AMBIENT, light_color);

	glLightfv(GL_LIGHT0 + index, GL_DIFFUSE, light_color);

	glLightfv(GL_LIGHT0 + index, GL_SPECULAR, light_color);

	glLightfv(GL_LIGHT0 + index, GL_POSITION, light_position);

	glLightfv(GL_LIGHT0 + index, GL_SPOT_DIRECTION, light_direction);

	glLightf(GL_LIGHT0 + index, GL_CONSTANT_ATTENUATION, constAtten);

	glLightf(GL_LIGHT0 + index, GL_LINEAR_ATTENUATION, linearAtten);

	glLightf(GL_LIGHT0 + index, GL_QUADRATIC_ATTENUATION, quadAtten);

	glLightf(GL_LIGHT0 + index, GL_SPOT_CUTOFF, cutOffAngle);

	glLightf(GL_LIGHT0 + index, GL_SPOT_EXPONENT, dropOffRate);
}