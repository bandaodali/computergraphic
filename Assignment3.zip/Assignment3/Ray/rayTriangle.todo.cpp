#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "rayTriangle.h"

////////////////////////
//  Ray-tracing stuff //
////////////////////////
void RayTriangle::initialize(void){
}
double RayTriangle::intersect(Ray3D ray,RayIntersectionInfo& iInfo,double mx){
	/*printf("Direction is %f,%f,%f\n", ray.direction.p[0], ray.direction.p[1], ray.direction.p[2]);*/
	Point3D normal = this[0].v[0]->normal;
	this[0].plane.normal = normal;
	Point3D p0 = ray.position;
	double distance = this[0].plane.distance;
	double t = distance - ray.position.dot(normal) / ray.direction.dot(normal);
	if (t <= 0) {
		return -1;
	}
	Point3D p = ray.position + ray.direction*t;
	/*Matrix3D m;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			m.index(i,j) = this[0].v[j]->position.index(i);
			printf("%f\t", m.index(i, j));
		}
		printf("\n");
	}
	Matrix3D n; m.Invert(m, n);
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			printf("%f\t", n.index(i, j));
		}
		printf("\n");
	}
	printf("\n");
	Point3D info = m * p;*/
	for (int i = 0; i < 3; i++) {
		Point3D v1 = this[0].v[i]->position - p0;
		Point3D v2 = this[0].v[(i+1)%3]->position - p0;
		Point3D n1 = v2.crossProduct(v1);
		if ((p - p0).dot(n1) < 0) {
			return -1.0;
		}
	}
	/*printf("RayTriangle iCoordinate is %f, %f, %f\n", p.p[0], p.p[1], p.p[2]);*/
	distance = (ray.direction*t).length();
	iInfo.iCoordinate = p;
	iInfo.normal = normal;
	iInfo.material = this[0].material;
	/*printf("normal is %f, %f, %f\n", iinfo.normal.p[0], iinfo.normal.p[1], iinfo.normal.p[2]);*/
	return distance;
}
BoundingBox3D RayTriangle::setBoundingBox(void){
	Point3D pList[3];
	pList[0] = v[0]->position;
	pList[1] = v[1]->position;
	pList[2] = v[2]->position;
	bBox = BoundingBox3D(pList, 3);
	for (int i = 0; i<3; i++) {
		bBox.p[0][i] -= RAYEPS;
		bBox.p[1][i] += RAYEPS;
	}
	return bBox;
}

//////////////////
// OpenGL stuff //
//////////////////
int RayTriangle::drawOpenGL(int materialIndex){
	material->drawOpenGL();
	glEnable(GL_NORMALIZE);
	glShadeModel(GL_SMOOTH);
	glBegin(GL_TRIANGLES);
	glNormal3f(v[0]->normal.p[0], v[0]->normal.p[1], v[0]->normal.p[2]);
	glTexCoord2d(0, 0);
	glVertex3f(v[0]->position.p[0], v[0]->position.p[1], v[0]->position.p[2]);
	glNormal3f(v[1]->normal.p[0], v[1]->normal.p[1], v[1]->normal.p[2]);
	glTexCoord2d(0, 1);
	glVertex3f(v[1]->position.p[0], v[1]->position.p[1], v[1]->position.p[2]);
	glNormal3f(v[2]->normal.p[0], v[2]->normal.p[1], v[2]->normal.p[2]);
	glTexCoord2d(1, 1);
	glVertex3f(v[2]->position.p[0], v[2]->position.p[1], v[2]->position.p[2]);
	glEnd();
	return material->index;
}
