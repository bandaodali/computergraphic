#include <stdlib.h>
#include <math.h>

#include <SVD/SVDFit.h>
#include <SVD/MatrixMNTC.h>

#include "geometry.h"


///////////////////////
// Ray-tracing stuff //
///////////////////////
double BoundingBox3D::intersect(const Ray3D& ray) const {
	// s + v*t
	Point3D s = ray.position;
	Point3D v = ray.direction;
	Point3D t0 = (p[0] - s) / v;
	Point3D t1 = (p[1] - s) / v;
	if (s.p[0] > p[0].p[0] && s.p[0] < s.p[0] < p[1].p[0] && s.p[1] > p[0].p[1] && s.p[1] < p[1].p[1] && s.p[2] > p[0].p[2] && s.p[2] < p[1].p[2]) {
		return 0;
	}
	double tmin = t0.p[0];
	double tmax = t1.p[0];
	if (tmin > tmax) {
		double temp = tmax;
		tmax = tmin;
		tmin = temp;
	}
	double tymin = t0.p[1];
	double tymax = t1.p[1];
	if (tymin > tymax) {
		double temp = tymax;
		tymax = tymin;
		tymin = temp;
	}

	if (tmin > tymax || tymin > tmax) {
		return -1;
	}
	if (tymin > tmin)
		tmin = tymin;
	if (tymax < tmax)
		tmax = tymax;

	double tzmin = t0.p[2];
	double tzmax = t1.p[2];
	if (tzmin > tzmax) {
		double temp = tzmax;
		tzmax = tzmin;
		tzmin = temp;
	}

	if (tmin > tzmax || tzmin > tmax) {
		return -1;
	}
	if (tzmin > tmin)
		tmin = tzmin;
	if (tzmax < tmax)
		tmax = tzmax;
	Point3D distence = s + v*tmin;
	return distence.length();
}

/////////////////////
// Animation stuff //
/////////////////////
Matrix3D::Matrix3D(const Point3D& e){
	(*this)=Matrix3D();
}

Matrix3D::Matrix3D(const Quaternion& q){
	(*this)=Matrix3D();
}
Matrix3D Matrix3D::closestRotation(void) const {
	return (*this);
}
/* While these Exp and Log implementations are the direct implementations of the Taylor series, the Log
 * function tends to run into convergence issues so we use the other ones:*/
Matrix3D Matrix3D::Exp(const Matrix3D& m,int iter){
	return m;



}
