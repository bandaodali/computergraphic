#ifndef TIME_INCLUDED
#define TIME_INCLUDED
/** This function returns the current time, in seconds. */
double GetTime(void);
#endif // TIME_INCLUDED
