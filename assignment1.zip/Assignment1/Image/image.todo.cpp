#include "image.h"
#include <stdlib.h>
#include <math.h>
#include <time.h>
#define PI 3.141592653

////////////////////////////
// Image processing stuff //
////////////////////////////
Pixel::Pixel(const Pixel32& p)
{
}
Pixel32::Pixel32(const Pixel& p)
{
}

int Image32::AddRandomNoise(const float& noise,Image32& outputImage) const
{	
	float numr, numg, numb;
	outputImage.setSize(this[0].width(), this[0].height());
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			/*if (i > 10 && i < 370 && j > 180 && j < 520) {
				outputImage.pixel(j, i).r = numb;
			}*/
			float realnoise = (noise - (float)(rand() % 100) * 2 * noise / 100.0)*255.0;
			numr = this[0].pixel(j, i).r + realnoise;
			numg = this[0].pixel(j, i).g + realnoise;
			numb = this[0].pixel(j, i).b + realnoise;
			
			if (numr <= 255 && numr >= 0) {
				outputImage.pixel(j, i).r = numr;
			}
			else {
				if (numr < 0)
					outputImage.pixel(j, i).r = 0;
				if (numr > 255)
					outputImage.pixel(j, i).r = 255;
			}

			if (numg <= 255 && numg >= 0) {
				outputImage.pixel(j, i).g = numg;
			}
			else {
				if (numg < 0)
					outputImage.pixel(j, i).g = 0;
				if (numg > 255)
					outputImage.pixel(j, i).g = 255;
			}
			if (numb <= 255 && numb >= 0) {
				outputImage.pixel(j, i).b = numb;
			}
			else {
				if (numb < 0)
					outputImage.pixel(j, i).b = 0;
				if (numr > 255)
					outputImage.pixel(j, i).b = 255;
			}
		}
	}	
	return 1;
}
int Image32::Brighten(const float& brightness,Image32& outputImage) const
{	
	outputImage = this[0];
	float numr, numg, numb;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			numr = outputImage.pixel(j, i).r * brightness;
			numg = outputImage.pixel(j, i).g * brightness;
			numb = outputImage.pixel(j, i).b * brightness;
			if (numr <= 255){
				outputImage.pixel(j, i).r = numr;
			}
			else
				outputImage.pixel(j, i).r = 255;
			if (numg <= 255) {
				outputImage.pixel(j, i).g = numg;
			}
			else
				outputImage.pixel(j, i).g = 255;
			if (numb <= 255) {
				outputImage.pixel(j, i).b = numb;
			}
			else
				outputImage.pixel(j, i).b = 255;
		}
	}
	return 1;
}
void Image32::CheckOverValue (float numr, float numg, float numb, int x, int y, Image32& outputImage) const
{
	if (numr <= 255 && numr >= 0) {
		outputImage.pixel(x, y).r = numr;
	}
	else {
		if (numr < 0)
			outputImage.pixel(x, y).r = 0;
		if (numr > 255)
			outputImage.pixel(x, y).r = 255;
	}

	if (numg <= 255 && numg >= 0) {
		outputImage.pixel(x, y).g = numg;
	}
	else {
		if (numg < 0)
			outputImage.pixel(x, y).g = 0;
		if (numg > 255)
			outputImage.pixel(x, y).g = 255;
	}
	if (numb <= 255 && numb >= 0) {
		outputImage.pixel(x, y).b = numb;
	}
	else {
		if (numb < 0)
			outputImage.pixel(x, y).b = 0;
		if (numr > 255)
			outputImage.pixel(x, y).b = 255;
	}
}


int Image32::Luminance(Image32& outputImage) const
{	
	outputImage = this[0];
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			int imageLuminance = 0.30*outputImage.pixel(j, i).r + 0.59 * outputImage.pixel(j, i).g + 0.11*outputImage.pixel(j, i).b;
			outputImage.pixel(j, i).r = imageLuminance;
			outputImage.pixel(j, i).g = imageLuminance;
			outputImage.pixel(j, i).b = imageLuminance;
		}
	}

	return 1;
}

int Image32::Contrast(const float& contrast,Image32& outputImage) const
{	
	outputImage = this[0];
	int averageLuminance = 0;
	for (int i = 0; i < outputImage.height(); i++) {
		int averageLuminanceRow = 0;
		for (int j = 0; j < outputImage.width(); j++) {
			int imageLuminance = 0.30*outputImage.pixel(j, i).r + 0.59 * outputImage.pixel(j, i).g + 0.11*outputImage.pixel(j, i).b;
			averageLuminanceRow += imageLuminance;
		}
		averageLuminanceRow = averageLuminanceRow / outputImage.width();
		averageLuminance += averageLuminanceRow;
	}
	averageLuminance = averageLuminance / outputImage.height();
	float numr, numg, numb;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			numr = (outputImage.pixel(j, i).r - averageLuminance)*contrast + averageLuminance;
			numg = (outputImage.pixel(j, i).g - averageLuminance)*contrast + averageLuminance;
			numb = (outputImage.pixel(j, i).b - averageLuminance)*contrast + averageLuminance;
			CheckOverValue(numr, numg, numb, j, i, outputImage);
		}
	}
	return 1;
}

int Image32::Saturate(const float& saturation,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width(), this[0].height());
	float numr, numg, numb;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			float luminance = 0.3*this[0].pixel(j, i).r + 0.59*this[0].pixel(j, i).g + 0.11*this[0].pixel(j, i).b;
			numr = (this[0].pixel(j, i).r - luminance)*saturation + luminance;
			numg = (this[0].pixel(j, i).g - luminance)*saturation + luminance;
			numb = (this[0].pixel(j, i).b - luminance)*saturation + luminance;
			CheckOverValue(numr, numg, numb, j, i, outputImage);
		}
	}
	return 1;
}

int Image32::Quantize(const int& bits,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width(), this[0].height());
	float factor = pow(2, bits);
	int divider = 256 / factor;
	float numr, numg, numb;
	for (int i = 0; i < outputImage.height(); i++) {			
		for (int j = 0; j < outputImage.width(); j++) {
			/*Pixel p = Pixel(this[0].pixel(j, i));
			numr = p.r * factor;
			numg = p.g * factor;
			numb = p.b * factor;
			outputImage.pixel(j, i).r = numr * divider;
			outputImage.pixel(j, i).g = numg * divider;
			outputImage.pixel(j, i).b = numb * divider;*/
			/*numr = this[0].pixel(j, i).r / divider * divider;
			numg = this[0].pixel(j, i).g / divider * divider;
			numb = this[0].pixel(j, i).b / divider * divider;*/
			numr = floor(this[0].pixel(j, i).r / 256.0 * factor);
			numg = floor(this[0].pixel(j, i).g / 256.0 * factor);
			numb = floor(this[0].pixel(j, i).b / 256.0 * factor);
			CheckOverValue(numr*divider, numg*divider, numb*divider, j, i, outputImage);
		}
	}
	return 1;
}

int Image32::RandomDither(const int& bits,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width(), this[0].height());
	int factor = pow(2, bits);
	int divider = 256 / factor;
	float numr, numg, numb;
	for (int i = 0; i < this[0].height(); i++) { 
		for (int j = 0; j < this[0].width(); j++) {
			float noise = 1 - (rand() % 100) * 2 / 100.0;
			numr = floor((this[0].pixel(j, i).r / 256.0 + noise / factor) * factor) * divider;
			numg = floor((this[0].pixel(j, i).g / 256.0 + noise / factor) * factor) * divider;
			numb = floor((this[0].pixel(j, i).b / 256.0 + noise / factor) * factor) * divider;
			CheckOverValue(numr, numg, numb, j, i, outputImage);
		}
	}
	return 1;
}
int Image32::OrderedDither2X2(const int& bits,Image32& outputImage) const
{
	outputImage.setSize(this[0].width(), this[0].height());
	int factor = pow(2, bits);
	int divider = 256 / factor;
	float numr, numg, numb;
	float cr, cg, cb;
	float er, eg, eb;
	int d[2][2] = { {1,3},{4,2} };
	for (int y = 0; y < this[0].height(); y++) {
		for (int x = 0; x < this[0].width(); x++) {
			int i = x % 2;
			int j = y % 2;
			cr = this[0].pixel(x, y).r/256.0 * (factor - 1);
			er = cr - floor(cr);
			if (er > d[i][j]/5.0)
				numr = ceil(cr) * divider;
			else
				numr = floor(cr) * divider;
			cg = this[0].pixel(x, y).g/256.0 * (factor - 1);
			eg = cg - floor(cg);
			if (eg > d[i][j]/5.0)
				numg = ceil(cg) * divider;
			else
				numg = floor(cg) * divider;
			cb = this[0].pixel(x, y).b/256.0 * (factor - 1);
			eb = cb - floor(cb);
			if (eb > d[i][j]/5.0)
				numb = ceil(cb) * divider;
			else
				numb = floor(cb) * divider;
			CheckOverValue(numr, numg, numb, x, y, outputImage);
		}
	}
	return 1;
}

int Image32::FloydSteinbergDither(const int& bits,Image32& outputImage) const
{	
	Image32 interImage;
	interImage.setSize(this[0].width() + 2, this[0].height() + 1);
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 1; j < this[0].width() + 1; j++) {
			interImage.pixel(j, i) = this[0].pixel(j - 1, i);
		}
	}
	float factor = pow(2, bits);
	int divider = 256 / factor;
	float numr, numg, numb;
	float errR, errG, errB;
	float addR, addG, addB;
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 1; j < this[0].width() + 1; j++) {
			numr = floor(interImage.pixel(j, i).r / 255.0 * factor);
			errR = interImage.pixel(j, i).r / 256.0 - numr / factor ;
			numg = floor(interImage.pixel(j, i).g / 255.0 * factor);
			errG = interImage.pixel(j, i).g / 256.0  - numg / factor;
			numb = floor(interImage.pixel(j, i).b / 255.0 * factor);
			errB = interImage.pixel(j, i).b / 256.0  - numb / factor;
			//right j+1
			addR = (interImage.pixel(j + 1, i).r / 256.0 + 7 * errR / 16.0) * 256;
			addG = (interImage.pixel(j + 1, i).g / 256.0 + 7 * errG / 16.0) * 256;
			addB = (interImage.pixel(j + 1, i).b / 256.0 + 7 * errB / 16.0) * 256;
			CheckOverValue(addR, addG, addB, j + 1, i, interImage);
			//leftdown j-1,i+1
			addR = (interImage.pixel(j - 1, i + 1).r / 256.0 + 3 * errR / 16.0) * 256;
			addG = (interImage.pixel(j - 1, i + 1).g / 256.0 + 3 * errG / 16.0) * 256;
			addB = (interImage.pixel(j - 1, i + 1).b / 256.0 + 3 * errB / 16.0) * 256;
			CheckOverValue(addR, addG, addB, j - 1, i + 1, interImage);
			//down j, i+1
			addR = (interImage.pixel(j, i + 1).r / 256.0 + 5 * errR / 16.0) * 256;
			addG = (interImage.pixel(j, i + 1).g / 256.0 + 5 * errG / 16.0) * 256;
			addB = (interImage.pixel(j, i + 1).b / 256.0 + 5 * errB / 16.0) * 256;
			CheckOverValue(addR, addG, addB, j, i + 1, interImage);
			// rightdown j + 1, i+1
			addR = (interImage.pixel(j + 1, i + 1).r / 256.0 + errR / 16.0) * 256;
			addG = (interImage.pixel(j + 1, i + 1).g / 256.0 + errG / 16.0) * 256;
			addB = (interImage.pixel(j + 1, i + 1).b / 256.0 + errB / 16.0) * 256;
			CheckOverValue(addR, addG, addB, j + 1, i + 1, interImage);
			CheckOverValue(numr * divider, numg * divider, numb * divider, j, i, interImage);
		}
	}
	outputImage.setSize(this[0].width(), this[0].height());
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 0; j < this[0].width(); j++) {
			outputImage.pixel(j, i) = interImage.pixel(j + 1, i);
		}
	}
	return 1;
}

int Image32::Blur3X3(Image32& outputImage) const
{	
	Image32 interImage;
	interImage.setSize(this[0].width() + 2, this[0].height() + 2);
	int blur[3][3] = { {1,2,1},{2,4,2},{1,2,1} };
	for (int i = 1; i < this[0].height() + 1; i++) {
		for (int j = 1; j < this[0].width() + 1; j++) {
			interImage.pixel(j, i) = this[0].pixel(j - 1, i - 1);
		}
	}
	float numr, numg, numb;
	for (int i = 1; i < interImage.height()-1; i++) {
		for (int j = 1; j < interImage.width()-1; j++) {
			numr = interImage.pixel(j - 1, i - 1).r / 16.0 + 2 * interImage.pixel(j, i - 1).r / 16.0 + interImage.pixel(j + 1, i - 1).r / 16.0 +
				2 * interImage.pixel(j - 1, i).r / 16.0 + 4 * interImage.pixel(j, i).r / 16.0 + 2 * interImage.pixel(j + 1, i).r / 16.0 +
				interImage.pixel(j - 1, i + 1).r / 16.0 + 2 * interImage.pixel(j, i + 1).r / 16.0 + interImage.pixel(j + 1, i + 1).r / 16.0;

			numg = interImage.pixel(j - 1, i - 1).g / 16.0 + 2 * interImage.pixel(j, i - 1).g / 16.0 + interImage.pixel(j + 1, i - 1).g / 16.0 +
				2 * interImage.pixel(j - 1, i).g / 16.0 + 4 * interImage.pixel(j, i).g / 16.0 + interImage.pixel(j + 1, i).g / 16.0 +
				interImage.pixel(j - 1, i + 1).g / 16.0 + 2 * interImage.pixel(j, i + 1).g / 16.0 + interImage.pixel(j + 1, i + 1).g / 16.0;

			numb = interImage.pixel(j - 1, i - 1).b / 16.0 + 2 * interImage.pixel(j, i - 1).b / 16.0 + interImage.pixel(j + 1, i - 1).b / 16.0 +
				2 * interImage.pixel(j - 1, i).b / 16.0 + 4 * interImage.pixel(j, i).b / 16.0 + interImage.pixel(j + 1, i).b / 16.0 +
				interImage.pixel(j - 1, i + 1).b / 16.0 + 2 * interImage.pixel(j, i + 1).b / 16.0 + interImage.pixel(j + 1, i + 1).b / 16.0;
			CheckOverValue(numr, numg, numb, j, i, interImage);
		}
	}
	outputImage.setSize(this[0].width(), this[0].height());
	for (int i = 0; i < this[0].height() ; i++) {
		for (int j = 0; j < this[0].width() ; j++) {
			outputImage.pixel(j, i) = interImage.pixel(j + 1, i + 1);
		}
	}
	return 1;
}

int Image32::EdgeDetect3X3(Image32& outputImage) const
{
	Image32 interImage;
	interImage.setSize(this[0].width() + 2, this[0].height() + 2);
	for (int i = 1; i < this[0].height() + 1; i++) {
		for (int j = 1; j < this[0].width() + 1; j++) {
			interImage.pixel(j, i) = this[0].pixel(j - 1, i - 1);
		}
	}
	float numr, numg, numb;
	float avgr = 0, avgg = 0, avgb = 0;
	outputImage.setSize(this[0].width(), this[0].height());
	for (int i = 1; i < this[0].height() - 1; i++) {
		for (int j = 1; j < this[0].width() - 1; j++) {
			numr = this[0].pixel(j, i).r - this[0].pixel(j - 1, i - 1).r / 8.0 - this[0].pixel(j, i - 1).r / 8.0 - this[0].pixel(j + 1, i - 1).r / 8.0 -
				this[0].pixel(j - 1, i).r / 8.0 - this[0].pixel(j + 1, i).r / 8.0 - this[0].pixel(j - 1, i + 1).r / 8.0 - this[0].pixel(j, i + 1).r / 8.0 - this[0].pixel(j + 1, i + 1).r / 8.0;
			if(numr > 0)
				avgr += numr;
			numg = this[0].pixel(j, i).g - this[0].pixel(j - 1, i - 1).g / 8.0 - this[0].pixel(j, i - 1).g / 8.0 - this[0].pixel(j + 1, i - 1).g / 8.0 -
				this[0].pixel(j - 1, i).g / 8.0 - this[0].pixel(j + 1, i).g / 8.0 - this[0].pixel(j - 1, i + 1).g / 8.0 - this[0].pixel(j, i + 1).g / 8.0 - this[0].pixel(j + 1, i + 1).g / 8.0;
			if(numg > 0)
				avgg += numg;
			numb = this[0].pixel(j, i).b - this[0].pixel(j - 1, i - 1).b / 8.0 - this[0].pixel(j, i - 1).b / 8.0 - this[0].pixel(j + 1, i - 1).b / 8.0 -
				this[0].pixel(j - 1, i).b / 8.0  - this[0].pixel(j + 1, i).b / 8.0 - this[0].pixel(j - 1, i + 1).b / 8.0 - this[0].pixel(j, i + 1).b / 8.0 - this[0].pixel(j + 1, i + 1).b / 8.0;
			if(numb > 0)
				avgb += numb;
			CheckOverValue(numr, numg, numb, j - 1, i - 1, outputImage);
		}
	}
	avgr = avgr / this[0].width() / this[0].height();
	avgg = avgg / this[0].width() / this[0].height();
	avgb = avgb / this[0].width() / this[0].height();
	printf("%f\t%f\t%f\n", avgr, avgg, avgb);
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			numr = outputImage.pixel(j, i).r;
			numg = outputImage.pixel(j, i).g;
			numb = outputImage.pixel(j, i).b;
			if (numr > 0) {
				numr = numr / avgr * 30;
			}
			if (numg > 0) {
				numg = numg / avgg * 30;
			}
			if (numb > 0) {
				numb = numb / avgb * 30;
			}
			CheckOverValue(numr, numg, numb, j, i, outputImage);
		}
	}
	return 1;
}
int Image32::ScaleNearest(const float& scaleFactor,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width()*scaleFactor, this[0].height()*scaleFactor);
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			int srcj = floor(j / scaleFactor + 0.5), srci = floor(i / scaleFactor + 0.5);
			outputImage.pixel(j, i) = this[0].pixel(srcj, srci);
		}
	}
	return 1;
}

int Image32::ScaleBilinear(const float& scaleFactor,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width()*scaleFactor, this[0].height()*scaleFactor);
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			float x = j / scaleFactor, y = i / scaleFactor;
			outputImage.pixel(j, i) = this[0].BilinearSample(x, y);
			/*float x1 = floor(x), y1 = floor(y);
			float x2 = x1 + 1, y2 = y1 + 1, dx = x - x1, dy = y - y1; 
			Pixel32 p, p1, p2;
			if (x2 < this[0].width() && y2 < this[0].height()) {
				p1.r = this[0].pixel(x1, y1).r * (1 - dx) + this[0].pixel(x2, y1).r*dx;
				p1.g = this[0].pixel(x1, y1).g * (1 - dx) + this[0].pixel(x2, y1).g*dx;
				p1.b = this[0].pixel(x1, y1).b * (1 - dx) + this[0].pixel(x2, y1).b*dx;
				p2.r = this[0].pixel(x1, y2).r * (1 - dx) + this[0].pixel(x2, y2).r*dx;
				p2.g = this[0].pixel(x1, y2).g * (1 - dx) + this[0].pixel(x2, y2).g*dx;
				p2.b = this[0].pixel(x1, y2).b * (1 - dx) + this[0].pixel(x2, y2).b*dx;
				p.r = p1.r * (1 - dy) + p2.r * dy;
				p.g = p1.g * (1 - dy) + p2.g * dy;
				p.b = p1.b * (1 - dy) + p2.b * dy;
			}
			else if (y2 < this[0].height()){
				p1.r = this[0].pixel(x1, y1).r * (1 - dx);
				p1.g = this[0].pixel(x1, y1).g * (1 - dx);
				p1.b = this[0].pixel(x1, y1).b * (1 - dx);
				p2.r = this[0].pixel(x1, y2).r * (1 - dx);
				p2.g = this[0].pixel(x1, y2).g * (1 - dx);
				p2.b = this[0].pixel(x1, y2).b * (1 - dx);
			}
			else if (x2 < this[0].width()) {
				p1.r = this[0].pixel(x1, y1).r * (1 - dx) + this[0].pixel(x2, y1).r*dx;
				p1.g = this[0].pixel(x1, y1).g * (1 - dx) + this[0].pixel(x2, y1).g*dx;
				p1.b = this[0].pixel(x1, y1).b * (1 - dx) + this[0].pixel(x2, y1).b*dx;
			}
			else {
				p1.r = this[0].pixel(x1, y1).r * (1 - dx);
				p1.g = this[0].pixel(x1, y1).g * (1 - dx);
				p1.b = this[0].pixel(x1, y1).b * (1 - dx);
			}
			if (y2 < this[0].height()) {
				p.r = p1.r * (1 - dy) + p2.r * dy;
				p.g = p1.g * (1 - dy) + p2.g * dy;
				p.b = p1.b * (1 - dy) + p2.b * dy;
			}
			else {
				p.r = p1.r * (1 - dy);
				p.g = p1.g * (1 - dy);
				p.b = p1.b * (1 - dy);
			}
			outputImage.pixel(j, i) = p;*/
		}
	}
	return 1;
}

int Image32::ScaleGaussian(const float& scaleFactor,Image32& outputImage) const
{	
	outputImage.setSize(this[0].width()*scaleFactor, this[0].height()*scaleFactor);
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			float x = j / scaleFactor, y = i / scaleFactor;
			float x1 = floor(x), y1 = floor(y);
			float x2 = x1 + 1, y2 = y1 + 1, w1, w2, w3, w4;
			float totalw = 0;
			w1 = exp(-(pow(x - x1, 2) + pow(y - y1, 2)));
			w2 = exp(-(pow(x - x2, 2) + pow(y - y1, 2)));
			w3 = exp(-(pow(x - x1, 2) + pow(y - y2, 2)));
			w4 = exp(-(pow(x - x2, 2) + pow(y - y2, 2)));
			if (x2 < this[0].width() && y2 < this[0].height()) {
				totalw = w1 + w2 + w3 + w4;
				outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w2 / totalw * this[0].pixel(x2, y1).r + w3 / totalw * this[0].pixel(x1, y2).r + w4 / totalw * this[0].pixel(x2, y2).r;

				outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w2 / totalw * this[0].pixel(x2, y1).g + w3 / totalw * this[0].pixel(x1, y2).g + w4 / totalw * this[0].pixel(x2, y2).g;

				outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w2 / totalw * this[0].pixel(x2, y1).b + w3 / totalw * this[0].pixel(x1, y2).b + w4 / totalw * this[0].pixel(x2, y2).b;
			}
			if (x2 >= this[0].width() && y2 >= this[0].height()) {
				outputImage.pixel(j, i).r = this[0].pixel(x1, y1).r;
				outputImage.pixel(j, i).g = this[0].pixel(x1, y1).g;
				outputImage.pixel(j, i).b = this[0].pixel(x1, y1).b;
			}
			else if (x2 >= this[0].width()) {
				totalw = w1 + w3;
				outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w3 / totalw * this[0].pixel(x1, y2).r;
				outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w3 / totalw * this[0].pixel(x1, y2).g;
				outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w3 / totalw * this[0].pixel(x1, y2).b;
			}
			else if (y2 >= this[0].height()) {
				totalw = w1 + w2;
				outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w2 / totalw * this[0].pixel(x2, y1).r;
				outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w2 / totalw * this[0].pixel(x2, y1).g;
				outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w2 / totalw * this[0].pixel(x2, y1).b;
			}
		}
	}
	return 1;
}

int Image32::RotateNearest(const float& angle, Image32& outputImage) const
{
	double realAngle = angle / 180 * PI;
	int height = this[0].height(), width = this[0].width();
	float w1 = fabs(cos(realAngle) * width + sin(realAngle) * height);
	float w2 = fabs(cos(realAngle) * width - sin(realAngle) * height);
	float h1 = fabs(sin(realAngle) * width + cos(realAngle) * height);
	float h2 = fabs(sin(realAngle) * width - cos(realAngle) * height);
	int outwidth, outheight;
	if (w1 > w2)
		outwidth = w1;
	else
		outwidth = w2;
	if (h1 > h2)
		outheight = h1;
	else
		outheight = h2;
	outputImage.setSize(outwidth, outheight);
	float moveX, moveY, x, y, u, v = 0;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			if (angle >= 0 && angle < 90) {
				moveX = 0;
				moveY = -sin(realAngle)*this[0].width();
			}

			if (angle >= 90 && angle < 180) {
				moveX = cos(realAngle)*this[0].width();
				moveY = -sin(realAngle)*this[0].width() + cos(realAngle)*this[0].height();
			}

			if (angle >= 180 && angle < 270) {
				moveX = cos(realAngle)*this[0].width() + sin(realAngle)*this[0].height();
				moveY = cos(realAngle)*this[0].height();
			}

			
			if (angle >= 270 && angle < 360) {
				moveX = sin(realAngle) * this[0].height();
				moveY = 0;
			}

			x = j + moveX;
			y = i + moveY;
			u = floor(x * cos(realAngle) - y * sin(realAngle) + 0.5);
			v = floor(x * sin(realAngle) + y * cos(realAngle) + 0.5);
			if (u >= 0 && u < this[0].width() && v >= 0 && v < this[0].height()) {
				outputImage.pixel(j, i) = this[0].pixel(u, v);
			}
		}
	}
	return 1;
}


int Image32::RotateBilinear(const float& angle,Image32& outputImage) const
{
	double realAngle = angle / 180 * PI;
	if (angle >= 0 && angle < 90) {
		outputImage.setSize(this[0].width()*cos(realAngle) + this[0].height()*sin(realAngle), this[0].width()*sin(realAngle) + this[0].height()*cos(realAngle));
	}
	if (angle >= 90 && angle < 180) {
		outputImage.setSize(this[0].height()*sin(realAngle) - this[0].width()*cos(realAngle), this[0].width()*sin(realAngle) - this[0].height()*cos(realAngle));
	}
	if (angle >= 180 && angle < 270) {
		outputImage.setSize(-this[0].width()*cos(realAngle) - this[0].height()*sin(realAngle), -this[0].width()*sin(realAngle) - this[0].height()*cos(realAngle));
	}
	if (angle >= 270 && angle < 360) {
		outputImage.setSize(this[0].width()*cos(realAngle) - this[0].height()*sin(realAngle), this[0].height()*cos(realAngle) - this[0].width()*sin(realAngle));
	}
	float moveX, moveY, x, y, u,v, u1, v1, u2, v2, du, dv= 0;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			if (angle >= 0 && angle < 90) {
				moveX = 0;
				moveY = -sin(realAngle)*this[0].width();
			}

			if (angle >= 90 && angle < 180) {
				moveX = cos(realAngle)*this[0].width();
				moveY = -sin(realAngle)*this[0].width() + cos(realAngle)*this[0].height();
			}

			if (angle >= 180 && angle < 270) {
				moveX = cos(realAngle)*this[0].width() + sin(realAngle)*this[0].height();
				moveY = cos(realAngle)*this[0].height();
			}


			if (angle >= 270 && angle < 360) {
				moveX = sin(realAngle) * this[0].height();
				moveY = 0;
			}

			x = j + moveX;
			y = i + moveY;
			u = x * cos(realAngle) - y * sin(realAngle);
			v = x * sin(realAngle) + y * cos(realAngle);
			if (u >= 0 && u < this[0].width() && v >= 0 && v < this[0].height()) {
				u1 = floor(u);
				v1 = floor(v);
				float u2 = u1 + 1, v2 = v1 + 1, du = u - u1, dv = u - u1;
				Pixel32 p, p1, p2;
				if (u2 < this[0].width() && v2 < this[0].height()) {
					p1.r = this[0].pixel(u1, v1).r * (1 - du) + this[0].pixel(u2, v1).r* du;
					p1.g = this[0].pixel(u1, v1).g * (1 - du) + this[0].pixel(u2, v1).g* du;
					p1.b = this[0].pixel(u1, v1).b * (1 - du) + this[0].pixel(u2, v1).b* du;
					p2.r = this[0].pixel(u1, v2).r * (1 - du) + this[0].pixel(u2, v2).r* du;
					p2.g = this[0].pixel(u1, v2).g * (1 - du) + this[0].pixel(u2, v2).g* du;
					p2.b = this[0].pixel(u1, v2).b * (1 - du) + this[0].pixel(u2, v2).b* du;
				}
				else if (v2 < this[0].height()) {
					p1.r = this[0].pixel(u1, v1).r * (1 - du);
					p1.g = this[0].pixel(u1, v1).g * (1 - du);
					p1.b = this[0].pixel(u1, v1).b * (1 - du);
					p2.r = this[0].pixel(u1, v2).r * (1 - du);
					p2.g = this[0].pixel(u1, v2).g * (1 - du);
					p2.b = this[0].pixel(u1, v2).b * (1 - du);
				}
				else if (u2 < this[0].width()) {
					p1.r = this[0].pixel(u1, v1).r * (1 - du) + this[0].pixel(u2, v1).r*du;
					p1.g = this[0].pixel(u1, v1).g * (1 - du) + this[0].pixel(u2, v1).g*du;
					p1.b = this[0].pixel(u1, v1).b * (1 - du) + this[0].pixel(u2, v1).b*du;
				}
				else {
					p1.r = this[0].pixel(u1, v1).r * (1 - du);
					p1.g = this[0].pixel(u1, v1).g * (1 - du);
					p1.b = this[0].pixel(u1, v1).b * (1 - du);
				}
				if (v2 < this[0].height()) {
					p.r = p1.r * (1 - dv) + p2.r * dv;
					p.g = p1.g * (1 - dv) + p2.g * dv;
					p.b = p1.b * (1 - dv) + p2.b * dv;
				}
				else {
					p.r = p1.r * (1 - dv);
					p.g = p1.g * (1 - dv);
					p.b = p1.b * (1 - dv);
				}
outputImage.pixel(j, i) = p;
			}
		}
	}
	return 1;
}

int Image32::RotateGaussian(const float& angle, Image32& outputImage) const
{
	double realAngle = angle / 180 * PI;
	if (angle >= 0 && angle < 90) {
		outputImage.setSize(this[0].width()*cos(realAngle) + this[0].height()*sin(realAngle), this[0].width()*sin(realAngle) + this[0].height()*cos(realAngle));
	}
	if (angle >= 90 && angle < 180) {
		outputImage.setSize(this[0].height()*sin(realAngle) - this[0].width()*cos(realAngle), this[0].width()*sin(realAngle) - this[0].height()*cos(realAngle));
	}
	if (angle >= 180 && angle < 270) {
		outputImage.setSize(-this[0].width()*cos(realAngle) - this[0].height()*sin(realAngle), -this[0].width()*sin(realAngle) - this[0].height()*cos(realAngle));
	}
	if (angle >= 270 && angle < 360) {
		outputImage.setSize(this[0].width()*cos(realAngle) - this[0].height()*sin(realAngle), this[0].height()*cos(realAngle) - this[0].width()*sin(realAngle));
	}
	float moveX, moveY, x, y, u, v = 0;
	for (int i = 0; i < outputImage.height(); i++) {
		for (int j = 0; j < outputImage.width(); j++) {
			if (angle >= 0 && angle < 90) {
				moveX = 0;
				moveY = -sin(realAngle)*this[0].width();
			}

			if (angle >= 90 && angle < 180) {
				moveX = cos(realAngle)*this[0].width();
				moveY = -sin(realAngle)*this[0].width() + cos(realAngle)*this[0].height();
			}

			if (angle >= 180 && angle < 270) {
				moveX = cos(realAngle)*this[0].width() + sin(realAngle)*this[0].height();
				moveY = cos(realAngle)*this[0].height();
			}


			if (angle >= 270 && angle < 360) {
				moveX = sin(realAngle) * this[0].height();
				moveY = 0;
			}

			u = j + moveX;
			v = i + moveY;
			x = u * cos(realAngle) - v * sin(realAngle);
			y = u * sin(realAngle) + v * cos(realAngle);
			if (x >= 0 && x < this[0].width() && y >= 0 && y < this[0].height()) {
				float x1 = floor(x), y1 = floor(y);
				float x2 = x1 + 1, y2 = y1 + 1, w1, w2, w3, w4;
				float totalw = 0;
				w1 = exp(-(pow(x - x1, 2) + pow(y - y1, 2)));
				w2 = exp(-(pow(x - x2, 2) + pow(y - y1, 2)));
				w3 = exp(-(pow(x - x1, 2) + pow(y - y2, 2)));
				w4 = exp(-(pow(x - x2, 2) + pow(y - y2, 2)));
				if (x2 < this[0].width() && y2 < this[0].height()) {
					totalw = w1 + w2 + w3 + w4;
					outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w2 / totalw * this[0].pixel(x2, y1).r + w3 / totalw * this[0].pixel(x1, y2).r + w4 / totalw * this[0].pixel(x2, y2).r;

					outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w2 / totalw * this[0].pixel(x2, y1).g + w3 / totalw * this[0].pixel(x1, y2).g + w4 / totalw * this[0].pixel(x2, y2).g;

					outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w2 / totalw * this[0].pixel(x2, y1).b + w3 / totalw * this[0].pixel(x1, y2).b + w4 / totalw * this[0].pixel(x2, y2).b;
				}
				if (x2 >= this[0].width() && y2 >= this[0].height()) {
					outputImage.pixel(j, i).r = this[0].pixel(x1, y1).r;
					outputImage.pixel(j, i).g = this[0].pixel(x1, y1).g;
					outputImage.pixel(j, i).b = this[0].pixel(x1, y1).b;
				}
				else if (x2 >= this[0].width()) {
					totalw = w1 + w3;
					outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w3 / totalw * this[0].pixel(x1, y2).r;
					outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w3 / totalw * this[0].pixel(x1, y2).g;
					outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w3 / totalw * this[0].pixel(x1, y2).b;
				}
				else if (y2 >= this[0].height()) {
					totalw = w1 + w2;
					outputImage.pixel(j, i).r = w1 / totalw * this[0].pixel(x1, y1).r + w2 / totalw * this[0].pixel(x2, y1).r;
					outputImage.pixel(j, i).g = w1 / totalw * this[0].pixel(x1, y1).g + w2 / totalw * this[0].pixel(x2, y1).g;
					outputImage.pixel(j, i).b = w1 / totalw * this[0].pixel(x1, y1).b + w2 / totalw * this[0].pixel(x2, y1).b;
				}
			}
		}
	}
	return 1;
}


int Image32::SetAlpha(const Image32& matte)
{	
	/*float numa;
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 0; j < this[0].width(); j++) {
			if (i < matte.height() && j < matte.width()) {
				numa = matte.pixel(j, i).a;
				this[0].pixel(j, i).a = numa;
			}			
		}
	}*/
	Image32 interImage;
	interImage.setSize(matte.width(), matte.height());
	int indexj = 20, indexi = 50, lock = 0;
	for (int i = 0; i < interImage.height(); i++) {
		for (int j = 0; j < interImage.width(); j++) {
			if (matte.pixel(j, i).r == 255) {
				lock = 1;
				if (indexj < matte.width() && indexi < matte.height())
					interImage.pixel(j, i) = this[0].pixel(indexj++, indexi);
			}
		}
		indexj = 20;
		if(lock == 1)
			indexi++;
	}
	this[0] = interImage;
	return 1;
}

int Image32::Composite(const Image32& overlay, Image32& outputImage) const
{
	float numr, numb, numg, numa;
	outputImage.setSize(this[0].width(), this[0].height()); 
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 0; j < this[0].width(); j++) {
			if (overlay.pixel(j, i).r != 0) {
				outputImage.pixel(j, i) = overlay.pixel(j, i);
			}
			else 
				outputImage.pixel(j, i) = this[0].pixel(j, i);
			/*if (i < overlay.height()-1 && j < overlay.width()-1 ) {
				numa = overlay.pixel(j, i).a + (1 - overlay.pixel(j, i).a/256.0)* this[0].pixel(j, i).a;
				numr = overlay.pixel(j, i).r * overlay.pixel(j, i).a + this[0].pixel(j, i).r * (1 - overlay.pixel(j, i).a / 256.0) * this[0].pixel(j, i).a;
				numr = numr / 256;				
				numg = overlay.pixel(j, i).g * overlay.pixel(j, i).a + this[0].pixel(j, i).g * (1 - overlay.pixel(j, i).a / 256.0) * this[0].pixel(j, i).a;
				numg = numg / 256;
				numb = overlay.pixel(j, i).b * overlay.pixel(j, i).a + this[0].pixel(j, i).b * (1 - overlay.pixel(j, i).a / 256.0) * this[0].pixel(j, i).a;
				numb = numb / 256;
				CheckOverValue(numr, numg, numb, j, i, outputImage);
				if (numa < 0) {
					numa = 0;
					outputImage.pixel(j, i).a = numa;
				}
				else if (numa > 255) {
					numa = 255;
					outputImage.pixel(j, i).a = numa;
				}
				else {
					outputImage.pixel(j, i).a = numa;
				}
			}*/
		}
	}
	return 1;
}

int Image32::CrossDissolve(const Image32& source,const Image32& destination,const float& blendWeight,Image32& ouputImage)
{
	return 0;
}
int Image32::Warp(const OrientedLineSegmentPairs& olsp,Image32& outputImage) const
{
	return 0;
}

int Image32::FunFilter(Image32& outputImage) const
{	
	double r = fmax(this[0].width(), this[0].height())/8;
	outputImage.setSize(this[0].width(), this[0].height());
	double x0 = this[0].width() / 2;
	double y0 = this[0].height() / 2;
	double angle = PI / 4;
	float x, y, rnew = 0, yoo = 0;
	for (int j = 0; j < outputImage.height(); j++) {
		for (int i = 0; i < outputImage.width(); i++) {
			if (j == r) {
				continue;
			}
			if (i < r) {
				float yoo = (pow(x0 - 2 * r, 2) + pow(r, 2) - pow(j, 2)) / 2 * (r - j);
				float rnew = sqrt(pow(x0 - 2 * r, 2) + pow(yoo - r, 2));
			}
			if (i >= r) {
				float yoo = (pow(x0 - 1, 2) + pow(r, 2) - pow(j, 2)) / 2 * (r - j);
				float rnew = sqrt(pow(x0 - 1, 2) + pow(yoo - r, 2));
			}
			if (pow(rnew, 2) < pow(i - x0, 2))
				rnew = fabs(i - x0);
			float y1 = (j - yoo) * sqrt(pow(rnew, 2) - pow(i - x0, 2)) / rnew + yoo;
			y1 = round(y1);
			if (y1 > this[0].height() -1) {
				y1 = this[0].height() - 1;
			}
			outputImage.pixel(i, j) = NearestSample(i, y1);
			//double dis = pow(pow(i - this[0].height()/2, 2) + pow(j - this[0].width()/2, 2), 0.5);
			//double chord = 2 * tan(angle / 2) * dis;
			//double dub = chord / (r*angle);
			//x = j * dub;
			//y = i * dub;
			////printf("%f\t %f\t %f\n", dub, x, y);
			//outputImage.pixel(j, i) = NearestSample(x, y);
		}
	}
	return 1;
}
int Image32::Crop(const int& x1,const int& y1,const int& x2,const int& y2,Image32& outputImage) const
{	
	outputImage.setSize(x2-x1+1, y2-y1+1);
	for (int i = 0; i < this[0].height(); i++) {
		for (int j = 0; j < this[0].width(); j++) {
			if (j >= x1 && j <= x2 && i >= y1 && i <= y2) {
				outputImage.pixel(j - x1, i - y1) = this[0].pixel(j, i);
			}
		}
	}
	return 1;
}


Pixel32 Image32::NearestSample(const float& x,const float& y) const
{
	if (x >= 0 && x < this[0].width()-1 && y >= 0 && y < this[0].height()-1) {
		int ix = floor(x + 0.5);
		int iy = floor(y + 0.5);
		return this[0].pixel(ix, iy);
}
	return Pixel32();
}
Pixel32 Image32::BilinearSample(const float& x,const float& y) const
{	
	float x1 = floor(x), y1 = floor(y);
	float x2 = x1 + 1, y2 = y1 + 1, dx = x - x1, dy = y - y1;
	Pixel32 p, p1, p2;
	if (x2 < this[0].width() && y2 < this[0].height()) {
		p1.r = this[0].pixel(x1, y1).r * (1 - dx) + this[0].pixel(x2, y1).r* dx;
		p1.g = this[0].pixel(x1, y1).g * (1 - dx) + this[0].pixel(x2, y1).g* dx;
		p1.b = this[0].pixel(x1, y1).b * (1 - dx) + this[0].pixel(x2, y1).b* dx;
		p2.r = this[0].pixel(x1, y2).r * (1 - dx) + this[0].pixel(x2, y2).r* dx;
		p2.g = this[0].pixel(x1, y2).g * (1 - dx) + this[0].pixel(x2, y2).g* dx;
		p2.b = this[0].pixel(x1, y2).b * (1 - dx) + this[0].pixel(x2, y2).b* dx;
	}
	else if (y2 < this[0].height()) {
		p1.r = this[0].pixel(x1, y1).r * (1 - dx);
		p1.g = this[0].pixel(x1, y1).g * (1 - dx);
		p1.b = this[0].pixel(x1, y1).b * (1 - dx);
		p2.r = this[0].pixel(x1, y2).r * (1 - dx);
		p2.g = this[0].pixel(x1, y2).g * (1 - dx);
		p2.b = this[0].pixel(x1, y2).b * (1 - dx);
	}
	else if (x2 < this[0].width()) {
		p1.r = this[0].pixel(x1, y1).r * (1 - dx) + this[0].pixel(x2, y1).r*dx;
		p1.g = this[0].pixel(x1, y1).g * (1 - dx) + this[0].pixel(x2, y1).g*dx;
		p1.b = this[0].pixel(x1, y1).b * (1 - dx) + this[0].pixel(x2, y1).b*dx;
	}
	else {
		p1.r = this[0].pixel(x1, y1).r * (1 - dx);
		p1.g = this[0].pixel(x1, y1).g * (1 - dx);
		p1.b = this[0].pixel(x1, y1).b * (1 - dx);
	}
	if (y2 < this[0].height()) {
		p.r = p1.r * (1 - dy) + p2.r * dy;
		p.g = p1.g * (1 - dy) + p2.g * dy;
		p.b = p1.b * (1 - dy) + p2.b * dy;
	}
	else {
		p.r = p1.r * (1 - dy);
		p.g = p1.g * (1 - dy);
		p.b = p1.b * (1 - dy);
	}
	return p;
}
Pixel32 Image32::GaussianSample(const float& x,const float& y,const float& variance,const float& radius) const
{	
	int range = 2 * radius + 1;
	float** cashe = new float*[range];
	Pixel32** cashep = new Pixel32*[range];
	float totalweight = 0;
	for (int i = 0; i < range; i++) {
		cashe[range] = new float[range];
		cashep[range] = new Pixel32[range];
	}
	int moveX, moveY, fx, fy;
	for (int i = 0; i < range; i++) {
		moveY = i - radius;
		fy = floor(i + moveY);
		for (int j = 0; j < range; j++) {
			moveX = j - radius;
			fx = floor(j + moveX);
			if (pow(x - fx, 2) + pow(y - fy, 2) <= pow(radius, 2)) {
				if (fx >= 0 && fx < this[0].width() && fy >= 0 && fy < this[0].height()) {
					cashe[j][i] = exp(-(pow((x - fx), 2) + pow(y - fy, 2)) / 2 * pow(variance, 2));
					cashep[j][i] = this[0].pixel(fx, fy);
					totalweight += cashe[j][i];
				}
			}
		}
	}
	Pixel32 p ;
	for (int i = 0; i < range; i++) {
		for (int j = 0; j < range; j++) {
			if (cashe[j][i] != 0 && totalweight > 0) {
				p.r = cashe[j][i] / totalweight * cashep[j][i].r;
				p.g = cashe[j][i] / totalweight * cashep[j][i].g;
				p.b = cashe[j][i] / totalweight * cashep[j][i].b;
			}
		}
	}
	if (totalweight == 0)
	{
		p.r = 0;
		p.g = 0;
		p.b = 0;
	}
	return p;
}
